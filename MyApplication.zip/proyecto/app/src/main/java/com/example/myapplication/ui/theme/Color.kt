package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFD0FF9A)
val Purple500 = Color(0xFF009688)
val Purple700 = Color(0xFF38993C)
val Teal200 = Color(0xFF03DAC5)