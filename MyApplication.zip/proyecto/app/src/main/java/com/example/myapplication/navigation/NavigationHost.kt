package com.example.myapplication.navigation

import android.app.Application
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModelProvider

import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.myapplication.database.ItemsViewModel
import com.example.myapplication.navigation.Routes.*
import com.example.myapplication.presentation.view.Ventana1
import com.example.myapplication.presentation.view.Ventana2
import com.example.myapplication.presentation.view.Ventana3
@Composable
fun NavigationHost(navController: NavHostController){

    NavHost(navController = navController, startDestination = Ventana1.route ){
        composable(Ventana1.route)
        {
            Ventana1(
                navegarPantalla2 = { newText ->
                    navController.navigate(Ventana2.createRoute(newText))
                }
            )
        }
        composable(
            Ventana2.route,
            arguments = listOf(navArgument("newText"){defaultValue=" "})
        )
        { navBackStackEntry ->
        var newText = navBackStackEntry.arguments?.getString("newText")
        val itemViewModel = ViewModelProvider(navController.currentBackStackEntry!!).get(ItemsViewModel::class.java)

        requireNotNull(newText)
        Ventana2(newText,itemViewModel)
        }
        composable(Ventana3.route)
        {
            Ventana3()
        }

    }
}