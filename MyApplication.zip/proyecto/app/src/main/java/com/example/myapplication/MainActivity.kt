package com.example.myapplication

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.runtime.Composable
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.database.Items
import com.example.myapplication.database.ItemsViewModel
import res.drawable.*
import com.example.myapplication.navigation.Routes.*
import com.example.myapplication.navigation.NavigationHost
import com.example.myapplication.presentation.components.BottomNavigationBar

import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val itemViewModel = ViewModelProvider(this).get(ItemsViewModel::class.java)
        setContent {
            MainViews()

        }
    }
    @Composable
    fun MainViews() {
        val navController = rememberNavController()
        val navigationItem = listOf(
            Ventana1,
            Ventana2,
            Ventana3
        )
        //scaffold provee una plantilla de materialdesing
        //ejemplo:navigation drawables,top bar ,botton navigation etc
        Scaffold(
            bottomBar = {
                BottomNavigationBar(
                    navController = navController,
                    items = navigationItem
                )
            }
        ) {
            NavigationHost(navController)
        }
    }
}
